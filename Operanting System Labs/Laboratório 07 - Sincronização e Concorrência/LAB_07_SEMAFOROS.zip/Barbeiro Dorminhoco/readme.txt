* Como compilar
    ~$ make

* Como rodar 
    ~$ ./main
    
* Como alterar a quantidade de: 
    - cadeiras de espera: alterar variavel NUMCHAIR
    - clientes: alterar variavel NUMTHREAD