## Laboratório 2 - Manipulação de Processos

### Como compilar
Exercício 01: `make exc1`  
Exercício 02: `make exc2`  
Exercício 03: `make exc3`

### Como executar  
Exercício 01: `./exc1` seguido do parametro esperado.  
Exercício 02: `./exc1` seguido do parametro esperado.  
Exercício 03: `./make exc1` seguido do parametro esperado.

### Exemplo de uso
    ~$ make exc1
    ~$ ./exc1 3